-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2019 at 09:14 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_automaticslight`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_complaint`
--

CREATE TABLE `tbl_complaint` (
  `id` int(11) NOT NULL,
  `lid` varchar(10) NOT NULL,
  `complaint` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_complaint`
--

INSERT INTO `tbl_complaint` (`id`, `lid`, `complaint`) VALUES
(1, '1', 'not working');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_register`
--

CREATE TABLE `tbl_register` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `consumer_no` varchar(50) NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_register`
--

INSERT INTO `tbl_register` (`user_id`, `username`, `email`, `password`, `consumer_no`, `status`) VALUES
(2, 'musthafap', 'musthafa@gmail.com', '1234', '1110', '2'),
(3, 'admin', 'musthafa.fabstudioz@gmail.com', '1234', 'v111111', '1'),
(4, 'sajin', 'sajin@gmail.com', '2345', '11102', '1'),
(5, 'abc', 'abc@g.c', '1111', '2222', '0'),
(6, 'xyz', 'xyz2g.c', '2222', '3333', '1'),
(7, 'yyy', 'yy@.c', '3333', '44444', '1'),
(8, 'sherin', 'sberin@gmail.com', '1234', '1110', '0'),
(9, 'sherin', 'sberin@gmail.com', '1234', '11101', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_complaints`
--

CREATE TABLE `tbl_user_complaints` (
  `complaint_id` int(11) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `post_no` varchar(50) NOT NULL,
  `complaint` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user_complaints`
--

INSERT INTO `tbl_user_complaints` (`complaint_id`, `user_email`, `post_no`, `complaint`) VALUES
(2, 'musthafa@gmail.com', 'P1010', 'not working'),
(3, 'musthafa.fabstudioz@gmail.com', 'P02', 'not working');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_complaint`
--
ALTER TABLE `tbl_complaint`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_register`
--
ALTER TABLE `tbl_register`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_user_complaints`
--
ALTER TABLE `tbl_user_complaints`
  ADD PRIMARY KEY (`complaint_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_complaint`
--
ALTER TABLE `tbl_complaint`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_register`
--
ALTER TABLE `tbl_register`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_user_complaints`
--
ALTER TABLE `tbl_user_complaints`
  MODIFY `complaint_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
